# FriendlyInterpolants
Friendly interpolation models compatible with pandas
